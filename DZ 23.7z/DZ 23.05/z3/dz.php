<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form action="" method="post">
<p>Выберите имя пользователя(login): 
    <select name="login">
		<option value="Petya">Petya</option>
		<option value="Slava">Slava</option>
		<option value="Grisha">Grisha</option>
	</select>
  <br>Введите пароль (passwd): 
	<input type="password" name="passwd"><br> 
	<p><input type="submit" value="Вход"> 
</form>
<?php
$method = getenv("REQUEST_METHOD");
if ($_POST["login"]=="Petya" && $_POST["passwd"]=="123") {
echo "Доступ к секретным страницам открыт <br/>"; 
}

elseif($_POST["login"]=="Slava" && $_POST["passwd"]=="321"){
echo "Доступ к секретным страницам открыт <br/>"; } 

elseif($_POST["login"]=="Grisha" && $_POST["passwd"]=="111"){
echo "Доступ к секретным страницам открыт <br/>"; }
else {echo "Неверный пароль";
} 

echo "<br/><br/> Petya (123);   Slava (321);  Grisha (111)"
?>
</body>
</html>

