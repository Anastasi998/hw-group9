
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form action="" method="post">
    <input type="text" name="login">
    <input type="password" name="password">
    <input type="submit">
</form>
<?php
$login = $_POST['login'];
$password = $_POST['password'];
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
echo "Логин: $login <br/>";
echo "Хэш-пароля: $hashed_password <br/>";
?>
</body>
</html>


