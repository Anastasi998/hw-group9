<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form action="" method="post">
<p>Выберите номер лабораторной: 
    <select name="lab">
		<option value="lab1">Лаб1</option>
		<option value="lab2">Лаб2</option>
		<option value="lab3">Лаб3</option>
		<option value="lab4">Лаб4</option>
	</select><br> <br> 
	<input type="submit" value="Сформировать ссылку"> 
</form>
<?php
$method = getenv("REQUEST_METHOD");
if ($_POST["lab"]=="lab1") {
echo "phpcourse.php?l=1 <br/>"; 
}

elseif($_POST["lab"]=="lab2"){
echo "phpcourse.php?l=2 <br/>"; } 

elseif($_POST["lab"]=="lab3"){
echo "phpcourse.php?l=3 <br/>"; }

elseif($_POST["lab"]=="lab4"){
echo "phpcourse.php?l=4 <br/>"; }
?>
</body>
</html>